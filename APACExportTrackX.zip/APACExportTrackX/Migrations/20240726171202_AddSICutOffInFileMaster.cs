﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class AddSICutOffInFileMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileActivityLog_ContainerMaster_ContainerId",
                table: "FileActivityLog");

            migrationBuilder.DropForeignKey(
                name: "FK_FileActivityLog_FileMaster_FileMasterId",
                table: "FileActivityLog");

            migrationBuilder.DropColumn(
                name: "SICutOff",
                table: "ContainerMaster");

            migrationBuilder.RenameColumn(
                name: "FileMasterId",
                table: "FileActivityLog",
                newName: "ContainerMasterId");

            migrationBuilder.RenameColumn(
                name: "ContainerId",
                table: "FileActivityLog",
                newName: "FileId");

            migrationBuilder.RenameIndex(
                name: "IX_FileActivityLog_FileMasterId",
                table: "FileActivityLog",
                newName: "IX_FileActivityLog_ContainerMasterId");

            migrationBuilder.RenameIndex(
                name: "IX_FileActivityLog_ContainerId",
                table: "FileActivityLog",
                newName: "IX_FileActivityLog_FileId");

            migrationBuilder.AddColumn<DateTime>(
                name: "SICutOff",
                table: "FileMaster",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivityLog_ContainerMaster_ContainerMasterId",
                table: "FileActivityLog",
                column: "ContainerMasterId",
                principalTable: "ContainerMaster",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivityLog_FileMaster_FileId",
                table: "FileActivityLog",
                column: "FileId",
                principalTable: "FileMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileActivityLog_ContainerMaster_ContainerMasterId",
                table: "FileActivityLog");

            migrationBuilder.DropForeignKey(
                name: "FK_FileActivityLog_FileMaster_FileId",
                table: "FileActivityLog");

            migrationBuilder.DropColumn(
                name: "SICutOff",
                table: "FileMaster");

            migrationBuilder.RenameColumn(
                name: "FileId",
                table: "FileActivityLog",
                newName: "ContainerId");

            migrationBuilder.RenameColumn(
                name: "ContainerMasterId",
                table: "FileActivityLog",
                newName: "FileMasterId");

            migrationBuilder.RenameIndex(
                name: "IX_FileActivityLog_FileId",
                table: "FileActivityLog",
                newName: "IX_FileActivityLog_ContainerId");

            migrationBuilder.RenameIndex(
                name: "IX_FileActivityLog_ContainerMasterId",
                table: "FileActivityLog",
                newName: "IX_FileActivityLog_FileMasterId");

            migrationBuilder.AddColumn<DateTime>(
                name: "SICutOff",
                table: "ContainerMaster",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivityLog_ContainerMaster_ContainerId",
                table: "FileActivityLog",
                column: "ContainerId",
                principalTable: "ContainerMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivityLog_FileMaster_FileMasterId",
                table: "FileActivityLog",
                column: "FileMasterId",
                principalTable: "FileMaster",
                principalColumn: "Id");
        }
    }
}
