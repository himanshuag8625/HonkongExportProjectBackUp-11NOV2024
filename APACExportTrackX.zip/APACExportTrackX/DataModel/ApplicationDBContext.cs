﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace APACExportTrackX.DataModel
{
    public class ApplicationDBContext : IdentityDbContext<ApplicationUser, Role, string>
	{
		public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
			: base(options)
		{


		}
		public override DbSet<ApplicationUser> Users { get; set; }
		public override DbSet<Role> Roles { get; set; }
		public virtual DbSet<ActivityMaster> ActivityMaster { get; set; }
		public virtual DbSet<CountryMaster> CountryMaster { get; set; }
		public virtual DbSet<FileActivityLog> FileActivityLog { get; set; }
		public virtual DbSet<FileMaster> FileMaster { get; set; }
		public virtual DbSet<HBLActivityLog> HBLActivityLog { get; set; }
		public virtual DbSet<HBLMaster> HBLMaster { get; set; }
		public virtual DbSet<StatusMaster> StatusMaster { get; set; }
		public virtual DbSet<AdhocFile> AdhocFile { get; set; }
		public virtual DbSet<AdhocHBL> AdhocHBL { get; set; }
		public virtual DbSet<AdhocFileActivityLog> AdhocFileActivityLog { get; set; }
		public virtual DbSet<AdhocHBLActivityLog> AdhocHBLActivityLog { get; set; }
		public virtual DbSet<FileAcitivityLogHistory> FileAcitivityLogHistory { get; set; }
		public virtual DbSet<HBLActivitylogHistory> HBLActivitylogHistory { get; set; }
		public virtual DbSet<ContainerMaster> ContainerMaster { get; set; }


	}

}
