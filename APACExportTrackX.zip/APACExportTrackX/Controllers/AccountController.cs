﻿using APACExportTrackX.DataModel;
using APACExportTrackX.LDAP;
using APACExportTrackX.ViewModels;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace CanadaExportTrackX.Controllers
{
    public class AccountController : Controller
	{
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly RoleManager<Role> roleManager;
        private readonly ApplicationDBContext _ctx;
        private readonly LdapUserManager<ApplicationUser> ldapUserManager;

        public AccountController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            RoleManager<Role> roleManager,
            ApplicationDBContext ctx,
            LdapUserManager<ApplicationUser> ldapUserManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
            this.ldapUserManager = ldapUserManager;
        }

        [HttpGet]
		public IActionResult Login()
		{
			return View(new LoginViewModel());
		}

        [Authorize(Roles = "Supervisor, Manager, Admin")]
        [HttpGet]
		public IActionResult Index(string userId)
		{
            ViewData["Roles"] = roleManager.Roles.ToList();

			var result = _ctx.Users.Select(x => new RegisterViewModel
			{
				FirstName = x.FirstName,
				LastName = x.LastName,
				UserName = x.UserName,
				CitrixId = x.CitrixId,
				EmpId = x.EmpId,
				IsActive = x.IsActive,
				IsDelete = x.IsDelete,
                IsLDAP = x.IsLDAP,
                IsReset = x.IsReset,
                //Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                RoleList = roleManager.Roles.ToList(),
                assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
            }).Where(x => x.IsDelete == false).ToList();
            ViewData["User"] = _ctx.Users.ToList();
            ViewData["Roles"] = roleManager.Roles.ToList();
            if (userId != null)
            {
				 result = _ctx.Users.Where(x => x.Id == userId).Select(x => new RegisterViewModel
				 {
					FirstName = x.FirstName,
					LastName = x.LastName,
					UserName = x.UserName,
					CitrixId = x.CitrixId,
					EmpId = x.EmpId,
                    IsActive = x.IsActive,
                    IsDelete = x.IsDelete,
                    IsLDAP = x.IsLDAP,
                    IsReset = x.IsReset,
                    //Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                    RoleList = roleManager.Roles.ToList(),
                    assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
                 }).Where(x => x.IsDelete == false).ToList();
                return Json(result);
			}
			return View(result);
		}
        
        [Authorize(Roles = "Supervisor, Manager, Admin")]
        [HttpGet]
		public IActionResult RestoreIndex(string userId)
		{
            ViewData["Roles"] = roleManager.Roles.ToList();

			var result = _ctx.Users.Select(x => new RegisterViewModel
			{
				FirstName = x.FirstName,
				LastName = x.LastName,
				UserName = x.UserName,
				CitrixId = x.CitrixId,
				EmpId = x.EmpId,
				IsActive = x.IsActive,
				IsDelete = x.IsDelete,
                IsLDAP = x.IsLDAP,
                IsReset = x.IsReset,
                //Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                RoleList = roleManager.Roles.ToList(),
                assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
            }).Where(x => (x.IsActive == null && x.IsDelete == null) || ((x.IsActive == true || x.IsActive == false || x.IsActive == null) && (x.IsDelete == true || x.IsDelete == null)) || (x.IsDelete == true || x.IsDelete == null || x.IsActive == null)).ToList();
            ViewData["User"] = _ctx.Users.ToList();
            ViewData["Roles"] = roleManager.Roles.ToList();
            if (userId != null)
            {
				 result = _ctx.Users.Where(x => x.Id == userId).Select(x => new RegisterViewModel
				 {
					FirstName = x.FirstName,
					LastName = x.LastName,
					UserName = x.UserName,
					CitrixId = x.CitrixId,
					EmpId = x.EmpId,
                    IsActive = x.IsActive,
                    IsDelete = x.IsDelete,
                    IsLDAP = x.IsLDAP,
                    IsReset = x.IsReset,
                    //Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                    RoleList = roleManager.Roles.ToList(),
                    assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
                 }).Where(x => (x.IsActive == null && x.IsDelete == null) || ((x.IsActive == true || x.IsActive == false || x.IsActive == null) && (x.IsDelete == true || x.IsDelete == null)) || (x.IsDelete == true || x.IsDelete == null || x.IsActive == null)).ToList();
                return Json(result);
			}
			return View(result);
		}
		
		[HttpPost]	
		public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
			{
                ApplicationUser users = _ctx.Users.Where(x => x.CitrixId == model.CitrixId).FirstOrDefault();
                if (users == null)
                {
                    ModelState.AddModelError(string.Empty, "Invalid user id.");
                    return View(model);
                }
                 if (users.IsLDAP == false || users.IsLDAP == null)
                 {
                    if (users.IsReset == false)
                    {
                        var result = await signInManager.PasswordSignInAsync(users, model.Password, false, false);
                        if (result.Succeeded)
                        {
                            var user = await userManager.FindByNameAsync(model.CitrixId);
                            var roles = await userManager.GetRolesAsync(user);

                            if (roles.Count != 0)
                            {
                                if (roles.Count() == 1)
                                {
                                    if (roles[0].ToString().ToLower() == "supervisor" || roles[0].ToString().ToLower() == "manager" || roles[0].ToString().ToLower() == "admin")
                                    {
                                        return RedirectToAction("Index", "Dashboard");
                                    }
                                    else if (roles[0].ToString().ToLower() == "user")
                                    {
                                        return RedirectToAction("UserThread", "User");
                                    }
                                }
                                else
                                    return RedirectToAction("SelectRole", "User");
                            }
                            else
                                ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                        }
                        ModelState.AddModelError("", "Invalid Login Attempt");
                        return View(model);
                    }
                    else
                    {

                        return RedirectToAction("ChangePassword", "Account", new { Username = users.CitrixId });
                    }
                }
                else
                {
                    var result = await ldapUserManager.CheckPasswordAsync(users, model.Password);
                    var userList = _ctx.Users.Where(x => x.IsActive == true && x.IsDelete == false);
                    if (result)
                    {
                        if (userList.Count() == 0)
                        {
                            ModelState.AddModelError(string.Empty, "User is inactive.");
                            return View(model);
                        }
                        await signInManager.SignInAsync(users, isPersistent: false);
                        var user = await userManager.FindByNameAsync(model.CitrixId);
                        var roles = await userManager.GetRolesAsync(user);
                        if (roles.Count != 0)
                        {
                            if (roles.Count() == 1)
                                {
                                    if (roles[0].ToString().ToLower() == "supervisor" || roles[0].ToString().ToLower() == "manager" || roles[0].ToString().ToLower() == "admin")
                                {
                                    return RedirectToAction("Index", "Dashboard");
                                }
                                else if (roles[0].ToString().ToLower() == "user")
                                {
                                    return RedirectToAction("UserThread", "User");
                                }
                                else
                                {
                                    return NotFound();
                                }
                            }
                            else
                                return RedirectToAction("SelectRole", "User");
                        }
                    }
                }
                
				//ModelState.AddModelError("", "Invalid Login Attempt");
				return View(model);
			}
			else
			{
				ModelState.AddModelError(string.Empty, "Invalid login attempt.");
				return View(model);
			}


		}

		[Authorize(Roles = "Supervisor, Manager, Admin")]
		[HttpGet]
		public IActionResult Register()
		{
            ViewData["Roles"] = roleManager.Roles.ToList();

            return View(new RegisterViewModel());
		}

		[Authorize(Roles = "Supervisor, Manager, Admin")]
		[HttpPost]
		public async Task<IActionResult> Register(RegisterViewModel model)
		{

            Console.Write("--------------------------------------------------------------");
            Console.Write(model.Role);
            if (ModelState.IsValid)
            {
				var userList = _ctx.Users.Where(x => x.CitrixId.ToLower() == model.CitrixId.ToLower() || x.UserName.ToLower() == model.UserName.ToLower() || x.EmpId == model.EmpId).ToList();
                
				if(userList == null || userList.Count == 0)
				{
                    var user = new ApplicationUser
                    {
                        CitrixId = model.CitrixId,
                        EmpId = model.EmpId,
                        UserName = model.UserName,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        IsActive = true,
                        NormalizedUserName = model.UserName.ToUpper()
                    };


                    var roleId = _ctx.Roles.Where(x => x.Name == model.Role).Select(x => x.Id).FirstOrDefault();

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = roleId,
                        UserId = user.Id,
                    });

                    var result = await userManager.CreateAsync(user);
                    _ctx.SaveChanges();
                    
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                        return Json("error");
                    }
                }
				else
				{
					return Json("UserName, CitrixId or EmpId already Exist.");
				}
            }

            return Json("success");
		}

        [Authorize(Roles = "Supervisor, Manager, Admin")]
        [HttpGet]
        public IActionResult EditUser(string Uname)
			{
            ViewData["EditUser"] = _ctx.Users.Where(x => x.UserName.ToLower() == Uname.Trim().ToLower() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        public async Task<JsonResult> EditUser(ApplicationUser model)
        {
            var uname = _ctx.Users.Where(x => x.Id == model.Id && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            if (uname != null)
            {
                uname.FirstName = model.FirstName.Trim();
                uname.LastName = model.LastName.Trim();
                uname.UserName = model.UserName.Trim();
                uname.CitrixId = model.CitrixId.Trim();
				uname.EmpId = model.EmpId;
                uname.NormalizedUserName = model.CitrixId.ToUpper().Trim();
                _ctx.Users.Update(uname);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }

        [HttpGet]
        public IActionResult ChangePassword(string Username)
        {
            if (Username == null)
            {
                if (User.Identity.IsAuthenticated)
                {
                    Username = userManager.GetUserName(User).ToString();
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            ViewData["User"] = userManager.Users.FirstOrDefault(x => x.CitrixId.ToLower() == Username.ToLower());

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            //var user = await userManger.GetUserAsync(User);

            //if (user == null)
            //{
            //    // Handle the case where the user is not found
            //    return NotFound();
            //}

            if (ModelState.IsValid)
            {
                ApplicationUser user = new ApplicationUser();

                if (User.Identity.IsAuthenticated)
                {
                    user = await userManager.GetUserAsync(User);
                }
                else
                {
                    user = _ctx.Users.FirstOrDefault(x => x.UserName == model.Username);
                    user.IsReset = false;
                    _ctx.Update(user);
                }

                var result = await userManager.ChangePasswordAsync(user, model.CurrentPassword.Trim(), model.NewPassword.Trim());

                if (result.Succeeded)
                {
                    return Json("success");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            return View("ChangePassword", model);
        }




        private bool IsPasswordValid(string password)
        {
            // Add your password validation logic here
            // For example, using a regular expression
            const string passwordRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$";
            return Regex.IsMatch(password, passwordRegex);
        }


        public IActionResult ResetPassword()
        {
            // Retrieve users based on role (in this case, "user")
            ViewData["User"] = _ctx.Users.ToList();
            return View();
        }

        // POST: /User/GeneratePassword
        [HttpPost]
        public IActionResult GeneratePassword(string userName)
        {
            // Generate random password
            string newPassword = GenerateRandomPassword();
            newPassword = newPassword.Trim();

            // Update user's password
            var user = userManager.FindByNameAsync(userName).Result;
            var token = userManager.GeneratePasswordResetTokenAsync(user).Result;
            var result = userManager.ResetPasswordAsync(user, token, newPassword).Result;


            if (result.Succeeded)
            {
                // Save the new password to the database or perform any other necessary actions
                // You can add code here to save the newPassword to the database
                // For simplicity, I'll assume you have a method like SavePasswordToDatabase(userId, newPassword)

                // SavePasswordToDatabase(userId, newPassword);

                // Return the new password to the view
                return Json(new { newPassword });
            }
            else
            {
                // Handle password reset failure
                return Json(new { error = "Password reset failed." });
            }
        }
        // While creating random password check validation for must contain at least 1 digit one uppercase and one special character
        private string GenerateRandomPassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
            var random = new Random();

            // Generate until the password meets the requirements
            string newPassword;
            do
            {
                newPassword = new string(Enumerable.Repeat(chars, 12)
                  .Select(s => s[random.Next(s.Length)]).ToArray());
            } while (!PasswordMeetsRequirements(newPassword));

            return newPassword;
        }

        private bool PasswordMeetsRequirements(string password)
        {
            // Check if the password contains at least one digit, one uppercase letter, and one special character
            return password.Any(char.IsDigit) && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(IsSpecialCharacter);
        }

        private bool IsSpecialCharacter(char c)
        {
            const string specialCharacters = "~!@#$%^&*()_+/`';.,/][}{:?<>";

            // Check if the character is a special character
            return specialCharacters.Contains(c);
        }

        [Authorize(Roles = "Supervisor, Manager, Admin")]
        [HttpPost]
        public async Task<JsonResult> UpdateRoles(UpdateRoleModel assignedRole)
        {
            var users = _ctx.Users.Where(x => x.CitrixId == assignedRole.UserId).FirstOrDefault();
            var userrole = _ctx.UserRoles.Where(x => x.UserId == users.Id).ToList();
            try
            {
                _ctx.RemoveRange(userrole);

                if (assignedRole.RoleList != null)
                    foreach (var multi in assignedRole.RoleList)
                    {
                        _ctx.UserRoles.Add(new IdentityUserRole<string>
                        {
                            UserId = users.Id,
                            RoleId = multi.RoleId,
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }

        public async Task<IActionResult> Logout()
		{
			await signInManager.SignOutAsync();
			return RedirectToAction("Login", "Account");
		}
	}
}
