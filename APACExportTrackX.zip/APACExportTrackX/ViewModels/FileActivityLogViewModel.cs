﻿namespace APACExportTrackX.ViewModels
{
    public class FileActivityLogViewModel
    {
        public string? FileId { get; set; }
        public string? FileLogId { get; set; }
        public string? ContainerNo { get; set; }
        public string? ContainerId { get; set; }
        public string? ActivityId { get; set; }
        public string? TelexId { get; set; }
        public string? TelexComment { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public string? SI { get; set; }
        public string? UserId { get; set; }
        public string? Roe { get; set; }
        public string? ATD { get; set; }
        public string? ETD { get; set; }
        public string? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
