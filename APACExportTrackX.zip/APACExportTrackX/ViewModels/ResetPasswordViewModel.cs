﻿using APACExportTrackX.DataModel;

namespace APACExportTrackX.ViewModels
{
    public class ResetPasswordViewModel
    {
        public IEnumerable<ApplicationUser> Users { get; set; }
        public string SelectedUserId { get; set; }
    }

}
